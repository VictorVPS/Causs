const help = (prefix) => {
	return `
<══════════════════════>
      *CAUSS BOT*
 <══════════════════════>

__█████████  ● ᏴϴͲ●ᎷᎬΝႮ●         
__█▄█████▄█   *DONO*    : CAUSS
__█▼▼▼▼▼█ 
_██ᏴϴͲ Ꮩ3.8██▌ 
__█▲▲▲▲▲█ 
__█████████ 
____██_____██

┌─────────❶.❷────────
║〘 INFORMAÇÕES 〙
║
╠🐉 *CAUSS BOT* 
╠🐉 𝐃𝐎𝐍𝐎:  ⃬⃗CAUSS (base dark) 
╠🐉 *wa.me/+5547992091566*
╠🐉 𝐒𝐓𝐀𝐓𝐔𝐒: ON
║
║
╠══🐰〘 MENU 〙🐰══
║
║🐊 *${prefix}figu*
║🐊 *${prefix}toimg*
║🐊 *${prefix}darkjokes (memes aleatórios)*
║🐊 *${prefix}memeindo*
║🐊 *${prefix}tts*
║🐊 *${prefix}lolih [on]*
║🐊 *${prefix}nsfwloli [off]*
║🐊 *${prefix}url2img*
║🐊 *${prefix}leens [na legenda]*
║🐊 *${prefix}wait [na legenda]*
║🐊 *${prefix}setprefix*
║
╠══🐰〘 OUTROS 〙🐰══
║
║🐊 *${prefix}linkgp*
║🐊 *${prefix}simih [1/0]*
║🐊 *${prefix}marcar*
║🐊 *${prefix}add [@]*
║🐊 *${prefix}banir [@]*
║🐊 *${prefix}promover [@]*
║🐊 *${prefix}rebaixar*
║🐊 *${prefix}admins*
║🐊 *${prefix}marcar2*
║🐊 *${prefix}bc [texto]* (ele faz uma ™)
║🐊 *${prefix}marcar3*
║🐊 *${prefix}bloqueados*
║🐊 *${prefix}bloquear [@]*
║🐊 *${prefix}desbloquear [@]*
║🐊 *${prefix}limpar*
║🐊 *${prefix}bc [ *texto* ]*
║🐊 *${prefix}bemvindo [1/0]*
║🐊 *${prefix}clonar [@]*
║🐊 *${prefix}help1*
║🐊 *${prefix}dono*
║🐊 *${prefix}owner*
║🐊 *${prefix}tts [texto]*
║🐊 *${prefix}setnome*
║🐊 *${prefix}termux*
║🐊 *${prefix}setfoto*
║🐊 *${prefix}grupoinfo*
║🐊 *${prefix}ytmp4*
║🐊 *${prefix}bomdia*
║🐊 *${prefix}boanoite*
║🐊 *${prefix}marcar*
║🐊 *${prefix}marcar2*
║🐊 *${prefix}marcar3*
║
╠══🐰〘 IMAGENS 〙🐰══
║
║🐊 *${prefix}loli* [off]
║🐊 *${prefix}loli1*
║🐊 *${prefix}hentai*
║🐊 *${prefix}dono*
║🐊 *${prefix}porno*
║🐊 *${prefix}boanoite*
║🐊 *${prefix}bomdia*
║🐊 *${prefix}boatarde*
║🐊 *${prefix}mia [aleatórias]*
║🐊 *${prefix}rize [aleatórias]*
║🐊 *${prefix}minato [aleatórias]*
║🐊 *${prefix}boruto [aleatórias]*
║🐊 *${prefix}hinata [aleatórias]*
║🐊 *${prefix}sasuke [aleatórias]*
║🐊 *${prefix}sakura [aleatórias]*
║🐊 *${prefix}naruto [aleatórias]*
║🐊 *${prefix}meme*   
║🐊 *${prefix}lofi*
║🐊 *${prefix}malkova*
║🐊 *${prefix}canal*
║🐊 *${prefix}nsfwloli1*
║🐊 *${prefix}reislin*
║
╠══🐰〘 INTELIGÊNCIA 〙🐰══
║
║🐊 *${prefix}simih 1 (para ativar)*
║🐊 *${prefix}simih 0 (para desativar)*
║ *${prefix}simi (sua mensagem)*
║
╠══🐰〘 EM PRODUÇÃO 〙🐰══
║
║🐊 *${prefix}gado*
║🐊 *${prefix}dbz*
║🐊 *${prefix}gtts loli*
║🐊 *${prefix}hidegp*
║🐊 *${prefix}grupos
║🐊 *${prefix}antinazismo
║🐊 *${prefix}it 1/0
║
╠══🐰〘 SÓ PREMIUM 〙🐰══
║
║🐊 *${prefix}dado*
║🐊 *${prefix}cekvip*
║🐊 *${prefix}premiumlist*
║🐊 *${prefix}delete*
║🐊 *${prefix}modapk*
║🐊 *${prefix}indo10*
║🐊 *${prefix}daftarvip [para virar Premium]*
║🐊 *${prefix}qrcode*
║🐊 *${prefix}chentai*
║🐊 *${prefix}gcpf*
║🐊 *${prefix}gbin*
║🐊 *${prefix}pack*
║🐊 *${prefix}destrava*
║🐊 *${prefix}gpessoa*
║
╠══🐰〘 GRUPO 〙🐰══
║
║🐊 *${prefix}banir*
║🐊 *${prefix}leveling [on/off]*
║🐊 *${prefix}level*
║🐊 *${prefix}add*
║🐊 *${prefix}promover*
║🐊 *${prefix}setfoto [na legenda]*
║🐊 *${prefix}setname [texto]*
║🐊 *${prefix}rebaixar*
║🐊 *${prefix}admins*
║🐊 *${prefix}marcar*
║🐊 *${prefix}marcar2*
║🐊 *${prefix}marcar3*
║🐊 *${prefix}bemvindo [1/0]*
║🐊 *${prefix}grupoinfo*
║🐊 *${prefix}bomdia*
║🐊 *${prefix}boatarde*
║🐊 *${prefix}boanoite*
║🐊 *${prefix}setdesc*
║🐊 *${prefix}bug [sua mensagem]*
║
╠══🐰〘 ESPECIFICO DO BOT 〙🐰══
║
║🐊 *${prefix}bug [sua mensagem]*
║🐊 *${prefix}clonar [@]*
║🐊 *${prefix}dono*
║🐊 *${prefix}ping [ver velocidade do bot]*
║🐊 *${prefix}termux*
║🐊 *${prefix}gay [@]*
║🐊 *${prefix}wame*
║🐊 *${prefix}map (nome)*
║🐊 *${prefix}setppbot (marque uma img)*
║🐊 *${prefix}pinterest (nome)*
║🐊 *${prefix}desligar (so para o dono)*
║🐊 *${prefix}timer*
║
╠══🐰〘 MAIS ALGUNS 〙🐰══
║
║🐊 *${prefix}neko*
║🐊 *${prefix}ttp [texto]*
║🐊 *${prefix}testime*
║🐊 *${prefix}tomp3*
║🐊 *${prefix}modoanime [on/off]*
║🐊 *${prefix}modonsfw [on/off]*
║🐊 *${prefix}happymod [jogo/app]*
║🐊 *${prefix}rize*
║🐊 *${prefix}ytsearch*
║🐊 *${prefix}moddroid [jogo/app]*
║🐊 *${prefix}xvideos [titulo]**
║🐊 *${prefix}nomegp*
║🐊 *${prefix}darkjokes (memes aleatórios)*
║🐊 *${prefix}animecry*
║🐊 *${prefix}gay1*
║🐊 *${prefix}next*
║🐊 *${prefix}alerta*
║🐊 *${prefix}belle [img aleatórias]*
║🐊 *${prefix}pronomeneu [texto]*
║🐊 *${prefix}hobby*
║🐊 *${prefix}kiss
║🐊 *${prefix}analise
║
╠══🐰〘 COMANDOS DE VOZ 〙🐰══
║
║🐊 *${prefix}ola*
║🐊 *${prefix}bv*
║🐊 *${prefix}tchau*
║🐊 *${prefix}bem*
║🐊 *${prefix}a*
║🐊 *${prefix}fdp*
║🐊 *${prefix}onich*
║🐊 *${prefix}beat1*
║🐊 *${prefix}glub*
║🐊 *${prefix}causs*
║
╠══🐰〘 OUTROS /2 〙🐰══
║
║🐊 *${prefix}antilink [1/0]*
║🐊 *${prefix}brainly [pergunta]*
║🐊 *${prefix}antiracismo [on/off]*
║🐊 *${prefix}setnomebot*
║🐊 *${prefix}meme*
║
╠══🐰〘 INTERATIVOS 〙🐰══
║
╠══NOTA »
║Mandar a msg sem o prefixo
╠════════════════════
║
║🐊 *bah*
║🐊 *oii*
║🐊 *bv*
║🐊 *canta ai bot*
║🐊 *grita*
║🐊 *causs*
║🐊 *gemidao*
║🐊 *musica*
║
╠══🐰〘 CAUSS NO CONTROLE 〙🐰══
║
║ *NOME: CAUSS*
║ *INSTA: animexx_png*
║ *WPP: wa.me/+5547992091566*
║ *YOUTUBE: https://youtube.com/c/caussZ*
║
║  *"base do lindo (DARK BOT 4.0)🐊🚩*
║  *"kiba não xereka"*
║  *Número do dark: wa.me/+5522996215481
║
╚═〘 CAUSS BOT 〙`
}

exports.help = help

