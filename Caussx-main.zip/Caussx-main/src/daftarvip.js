const daftarvip = (prefix) => { 
	return `
	
*PREÇO DE LISTA VIP :*

-Rp. 10 > Acessar recursos ViP
-Rp. 20 > Recursos VIP + Insira o bot no seu grupo!

*SE QUER REGISTAR VIP :*

*Proprietário do bate-papo BOT :*

_wa.me/554792091566 ou digite *${prefix}owner*_

*NOTA*

*GRUPO DO CAUSS 🐊🚩 :*
_https://chat.whatsapp.com/IrKmqmFSUsUA1NUPS7D52l_ `
}
exports.daftarvip = daftarvip